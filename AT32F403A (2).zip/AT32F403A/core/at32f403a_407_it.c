/**
  ******************************************************************************
  * @file    at32f403a_407_it.c
  * @author  Artery Technology
  * @version V2.2.1
  * @date    2025/05/31
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and
  *          peripherals interrupt service routine.
  ******************************************************************************
  *
  * Copyright (c) 2025, Artery Technology, All rights reserved.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "at32f403a_407.h"
#include "usart.h"


extern uint32_t SystickTime;
extern volatile uint32_t g_msTicks;
/** @addtogroup AT32F403A_StdPeriph_Template
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M3 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
  * @brief  This function handles NMI exception.
  * @param  None
  * @retval None
  */
void NMI_Handler(void)
{
}

/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
	UsartPrintf(USART_DEBUG, "\r\n*******************HardFault_Handler*******************\r\n");
  while (1)
  {
  }
}

/**
  * @brief  This function handles Memory Manage exception.
  * @param  None
  * @retval None
  */
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
	UsartPrintf(USART_DEBUG, "\r\n*******************MemManage_Handler*******************\r\n");
  while (1)
  {
  }
}

/**
  * @brief  This function handles Bus Fault exception.
  * @param  None
  * @retval None
  */
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
	UsartPrintf(USART_DEBUG, "\r\n*******************BusFault_Handler*******************\r\n");
  while (1)
  {
  }
}

/**
  * @brief  This function handles Usage Fault exception.
  * @param  None
  * @retval None
  */
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
	UsartPrintf(USART_DEBUG, "\r\n*******************UsageFault_Handler*******************\r\n");
  while (1)
  {
  }
}

/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{
}

/**
  * @brief  This function handles Debug Monitor exception.
  * @param  None
  * @retval None
  */
void DebugMon_Handler(void)
{
}

/**
  * @brief  This function handles PendSVC exception.
  * @param  None
  * @retval None
  */
//void PendSV_Handler(void) //UCOS系统中不写在这里
//{
//}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
void SysTick_Handler(void)
{
	g_msTicks++;
    //SystickTime_Increase();
    //SystickTime++;
}

/******************************************************************************/
/*                 AT32F403A Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_at32f403a_407.s).                                           */
/******************************************************************************/


void EXINT0_IRQHandler(void)
{

}

/**
  * @brief  This function handles usart1 global interrupt request.
  * @param  None
  * @retval : None
  */
//void USART1_IRQHandler(void)
//{
//		unsigned int data;

//    if(USART1->SR & 0x0F)
//    {
//        // See if we have some kind of error
//        // Clear interrupt (do nothing about it!)
//        data = USART1->DR;
//    }
//    else if(USART1->SR & USART_FLAG_RXNE)      //Receive Data Reg Full Flag
//    {		
//        data = USART1->DR;
//				//usart1_putrxchar(data);     //Insert received character into buffer                     
//    }
//		else
//		{;}
//}

/**
  * @brief  This function handles usart2 global interrupt request.
  * @param  None
  * @retval : None
  */
//void USART2_IRQHandler(void)
//{
//		unsigned int data;

//    if(USART2->SR & 0x0F)
//    {
//        // See if we have some kind of error
//        // Clear interrupt (do nothing about it!)
//        data = USART2->DR;
//    }
//		else if(USART2->SR & USART_FLAG_RXNE)   //Receive Data Reg Full Flag
//    {		
//        data = USART2->DR;
//				usart2_rcv_buf[usart2_rcv_len++]=data;
//				
//				if(data=='{') //约定平台下发的控制命令以'{'为开始符，‘}’为控制命令结束符，读者可以自定义自己的开始符合结束符
//				{
//						rcv_cmd_start=1;
//				}
//				if(rcv_cmd_start==1)
//				{
//						usart2_cmd_buf[usart2_cmd_len++]=data;
//						if((data=='}')||(usart2_cmd_len>=MAX_CMD_LEN-1))
//						{
//								rcv_cmd_start=0;
//								LED_CmdCtl();
//								memset(usart2_cmd_buf,0,usart2_cmd_len);
//        				usart2_cmd_len=0;
//						}
//				}	  
//    }
//		else
//		{
//				;
//		}
//}

/**
  * @brief  This function handles RTC global interrupt request.
  * @param  None
  * @retval : None
  */
void RTC_IRQHandler(void)
{
   
}

/**
  * @brief  This function handles PPP interrupt request.
  * @param  None
  * @retval None
  */
/*void PPP_IRQHandler(void)
{
}*/

/**
  * @}
  */ 


/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
